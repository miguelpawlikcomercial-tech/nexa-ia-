import React,{useState,useEffect, useRef} from 'react';
const BACKEND=import.meta.env.VITE_BACKEND_URL||'http://localhost:3000';
export default function App(){
  const [user,setUser]=useState(null);
  const [messages,setMessages]=useState([]);
  const [input,setInput]=useState('');
  const [file,setFile]=useState(null);
  const [prompt,setPrompt]=useState('');
  const [loading,setLoading]=useState(false);
  const messagesRef=useRef(null);
  useEffect(()=>{checkAuth()},[]);
  useEffect(()=>{messagesRef.current?.scrollTo({top:messagesRef.current.scrollHeight,behavior:'smooth'})},[messages]);
  async function checkAuth(){
    const res=await fetch(BACKEND+'/api/me',{credentials:'include'});
    const data=await res.json();setUser(data.user);
  }
  const loginGoogle=()=>window.location.href=BACKEND+'/api/auth/google';
  const logout=async()=>{await fetch(BACKEND+'/api/logout',{credentials:'include'});setUser(null);};
  const sendChat=async()=>{if(!input.trim())return;setMessages([...messages,{role:'user',content:input}]);setLoading(true);
    try{const res=await fetch(BACKEND+'/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'include',body:JSON.stringify({messages:[...messages,{role:'user',content:input}],systemPrompt:'Você é útil e responde em português'})});
    if(res.status===401){setMessages([...messages,{role:'assistant',content:'Precisa se autenticar'}]);setLoading(false);return;}
    const data=await res.json();setMessages([...messages,data.assistant]);}catch(e){console.error(e);}finally{setInput('');setLoading(false);}};
  const uploadFile=async()=>{if(!file)return;setLoading(true);const fd=new FormData();fd.append('file',file);
    try{const res=await fetch(BACKEND+'/api/summarize',{method:'POST',body:fd,credentials:'include'});const data=await res.json();setMessages([...messages,{role:'assistant',content:data.summary||data.error}]);}catch(e){console.error(e);}finally{setFile(null);setLoading(false);}};
  const genImage=async()=>{if(!prompt.trim())return;setLoading(true);
    try{const res=await fetch(BACKEND+'/api/generate-image',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'include',body:JSON.stringify({prompt})});const data=await res.json();if(data.url)setMessages([...messages,{role:'assistant',content:<img src={data.url} alt="imagem gerada" style={{maxWidth:200}}/>}]);}catch(e){console.error(e);}finally{setLoading(false);}};
  const genVideo=async()=>{if(!prompt.trim())return;setLoading(true);
    try{const res=await fetch(BACKEND+'/api/generate-video',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'include',body:JSON.stringify({prompt})});const data=await res.json();
      if(data.video_urls)setMessages([...messages,{role:'assistant',content:data.video_urls.map((u,i)=><img key={i} src={u} alt="frame video" style={{maxWidth:150,marginRight:4}}/>) }]);
    }catch(e){console.error(e);}finally{setLoading(false);}};
  return(<div style={{maxWidth:900,margin:'20px auto',padding:20,border:'1px solid #ccc',borderRadius:8}}>
    <h1>Nexa IA</h1>
    {user? <div>Olá {user.name} <button onClick={logout}>Sair</button></div>:<button onClick={loginGoogle}>Entrar com Google</button>}
    <div ref={messagesRef} style={{height:300,overflow:'auto',border:'1px solid #eee',padding:8,marginTop:12}}>
      {messages.map((m,i)=><div key={i} style={{margin:'6px 0',background:m.role==='user'?'#e0f2fe':'#eef2ff',padding:6,borderRadius:4}}>{m.role}: {m.content}</div>)}
    </div>
    <input type="text" placeholder="Digite..." value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>e.key==='Enter'&&sendChat()} style={{width:'100%',marginTop:8,padding:6}}/>
    <button onClick={sendChat} disabled={loading}>Enviar</button>
    <hr/>
    <input type="file" onChange={e=>setFile(e.target.files[0])}/>
    <button onClick={uploadFile} disabled={loading||!file}>Enviar & Resumir</button>
    <hr/>
    <input type="text" placeholder="Prompt para gerar imagem ou vídeo" value={prompt} onChange={e=>setPrompt(e.target.value)} style={{width:'100%',padding:6}}/>
    <button onClick={genImage} disabled={loading}>Gerar Imagem</button>
    <button onClick={genVideo} disabled={loading}>Gerar Vídeo Realista (MVP)</button>
  </div>);
}
