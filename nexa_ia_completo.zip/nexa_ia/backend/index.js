import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import passport from 'passport';
import session from 'express-session';
import { Strategy as GoogleStrategy } from 'passport-google-oauth20';
import db from './db.js';
import multer from 'multer';
import fetch from 'node-fetch';
import pdf from 'pdf-parse';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import imageio from 'imageio'; // placeholder, simulação
dotenv.config();

const app = express();
app.use(cors({ origin: 'http://localhost:5173', credentials: true }));
app.use(express.json());

app.use(session({
  secret: process.env.COOKIE_SECRET || 'troque_esta_chave',
  resave: false, saveUninitialized: false, cookie: { secure: false }
}));

app.use(passport.initialize());
app.use(passport.session());

passport.serializeUser((user, done)=> done(null,user.id));
passport.deserializeUser((id, done)=> {
  const row = db.prepare('SELECT * FROM users WHERE id=?').get(id);
  done(null,row||null);
});

passport.use(new GoogleStrategy({
  clientID: process.env.GOOGLE_CLIENT_ID,
  clientSecret: process.env.GOOGLE_CLIENT_SECRET,
  callbackURL: process.env.GOOGLE_CALLBACK_URL
}, (accessToken, refreshToken, profile, done)=>{
  let user = db.prepare('SELECT * FROM users WHERE google_id=?').get(profile.id);
  if(!user){
    const info = db.prepare('INSERT INTO users (google_id,email,name,picture) VALUES(?,?,?,?)').run(
      profile.id, profile.emails?.[0]?.value||null, profile.displayName||null, profile.photos?.[0]?.value||null
    );
    user = db.prepare('SELECT * FROM users WHERE id=?').get(info.lastInsertRowid);
  }
  return done(null,user);
}));

// Auth routes
app.get('/api/auth/google', passport.authenticate('google',{scope:['profile','email']}));
app.get('/api/auth/google/callback', passport.authenticate('google',{failureRedirect:'/auth/failure'}),
  (req,res)=>res.redirect('http://localhost:5173/?auth=success'));
app.get('/api/logout',(req,res)=>{req.logout(()=>{});req.session.destroy(()=>{res.clearCookie('connect.sid');res.json({ok:true});});});
app.get('/api/me',(req,res)=>res.json({user:req.user?{id:req.user.id,google_id:req.user.google_id,email:req.user.email,name:req.user.name,picture:req.user.picture}:null}));

function ensureAuth(req,res,next){if(req.isAuthenticated && req.isAuthenticated()) return next(); res.status(401).json({error:'Não autenticado'});}

const upload = multer({storage:multer.memoryStorage(),limits:{fileSize:10*1024*1024}});

// Chat endpoint
app.post('/api/chat', ensureAuth, async (req,res)=>{
  try{
    const {messages, systemPrompt} = req.body;
    if(!messages||!Array.isArray(messages)) return res.status(400).json({error:'messages array required'});
    const payload = {model:process.env.MODEL, messages:[{role:'system',content:systemPrompt||'Você é um assistente útil que fala em português.'}, ...messages]};
    const r = await fetch('https://api.openai.com/v1/chat/completions',{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${process.env.OPENAI_API_KEY}`},body:JSON.stringify(payload)});
    const data = await r.json();
    res.json({assistant:data.choices?.[0]?.message || {role:'assistant',content:data.choices?.[0]?.text||''}});
  }catch(e){console.error(e);res.status(500).json({error:'erro interno'});}
});

// Summarize upload
app.post('/api/summarize', ensureAuth, upload.single('file'), async (req,res)=>{
  try{
    if(!req.file) return res.status(400).json({error:'Nenhum arquivo enviado'});
    let text='';
    const mimetype=req.file.mimetype||'';
    if(mimetype==='application/pdf'||path.extname(req.file.originalname).toLowerCase()==='.pdf'){
      const data = await pdf(req.file.buffer); text=data.text||'';
    } else { text=req.file.buffer.toString('utf-8'); }
    const prompt = `Resuma o texto a seguir em português:\n\n${text.slice(0,30000)}`;
    const payload={model:process.env.MODEL,messages:[{role:'system',content:'Você resume textos em português.'},{role:'user',content:prompt}],max_tokens:800};
    const r = await fetch('https://api.openai.com/v1/chat/completions',{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${process.env.OPENAI_API_KEY}`},body:JSON.stringify(payload)});
    const data = await r.json();
    res.json({summary:data.choices?.[0]?.message?.content||data.choices?.[0]?.text||''});
  }catch(e){console.error(e);res.status(500).json({error:'erro interno'});}
});

// Generate image
app.post('/api/generate-image', ensureAuth, async (req,res)=>{
  try{
    const { prompt } = req.body;
    if(!prompt) return res.status(400).json({error:'prompt necessário'});
    const r = await fetch('https://api.openai.com/v1/images/generations',{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${process.env.OPENAI_API_KEY}`},body:JSON.stringify({prompt,size:'1024x1024',n:1})});
    const data = await r.json();
    res.json({url:data.data?.[0]?.url||null});
  }catch(e){console.error(e);res.status(500).json({error:'erro interno'});}
});

// Generate video (MVP realista via GIF de 3 imagens)
app.post('/api/generate-video', ensureAuth, async (req,res)=>{
  try{
    const { prompt } = req.body;
    if(!prompt) return res.status(400).json({error:'prompt necessário'});
    const urls=[];
    for(let i=0;i<3;i++){
      const r = await fetch('https://api.openai.com/v1/images/generations',{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${process.env.OPENAI_API_KEY}`},body:JSON.stringify({prompt:size:'512x512',n:1})});
      const data = await r.json();
      urls.push(data.data?.[0]?.url);
    }
    res.json({video_urls:urls,note:'MVP: sequência de 3 imagens simulando vídeo curto'});
  }catch(e){console.error(e);res.status(500).json({error:'erro interno'});}
});

app.listen(process.env.PORT||3000,()=>console.log('Backend rodando com vídeo realista MVP...'));
