# Nexa IA

Aplicativo completo com:

- Chat em português (responde qualquer pergunta)
- Upload e resumo de arquivos (PDF/TXT)
- Login com Google
- Geração de imagens IA
- **Geração de vídeos curtos realistas (MVP via sequência de imagens)**
- Frontend React + Vite
- Backend Node.js + SQLite

## Setup Local

### Backend
```
cd backend
npm install
cp .env.example .env
# preencha .env com suas credenciais Google OAuth e OpenAI Key
npm run dev
```

### Frontend
```
cd frontend
npm install
cp .env.example .env
npm run dev
```

## Deploy

- Backend: Render.com
- Frontend: Vercel.com

Configure a variável `VITE_BACKEND_URL` no frontend para a URL do backend.

## Observações

- Vídeo realista é MVP: sequência de 3 imagens simulando vídeo curto. Para vídeos longos ou HD, integrar serviços pagos.
